#!/bin/sh
printf '\033c\033]0;%s\a' Lilly Valley
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Lilly Valley.x86_64" "$@"
